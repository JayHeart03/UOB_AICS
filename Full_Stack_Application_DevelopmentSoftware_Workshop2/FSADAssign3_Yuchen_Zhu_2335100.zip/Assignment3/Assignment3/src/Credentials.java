//Replace these with your own!

public class Credentials {
    //JDBC connection
    public static final String USERNAME = "postgres";
    public static final String PASSWORD = "Zyc700121";
    public static final String URL = "jdbc:postgresql://localhost:5432/Music";
    //Client-server connection
    public static final String HOST = "127.0.0.1"; //localhost
    public static final int PORT = 80;
}
